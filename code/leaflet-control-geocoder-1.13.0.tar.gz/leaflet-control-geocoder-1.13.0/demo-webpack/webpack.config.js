/* eslint-env node */
module.exports = {
  mode: 'production',
  entry: './main.js',
  output: {
    filename: './bundle.js'
  }
};
